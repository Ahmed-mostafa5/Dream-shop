Dreem Shop - Ready to Upload

Main page: index.html
Upload all files in this folder to your hosting public folder.
The site uses external image URLs, so no image folder is required.
